
import java.util.*;

// FIND ALL OF THE FINISH ME comments
// and add the necessary code

public class Student implements Comparable
{
 String name;
 String id;
 String age;
 ArrayList <Integer> grades;
 
 public Student(String theName, String theId, String theAge,
                ArrayList<Integer> theGrades)
 {
  name = theName;
  
  grades = theGrades;
  
   // FINISH ME                
   age = theAge;
   
   id = theId;
   
 } 
 
 
 public String getName()
 {
   // FINISH ME
    
  return name;  // replace me
 }

 public String getId()
 {
   // FINISH ME

  return id;  // replace me
 }

 public String getAge()
 {
   // FINISH ME

  return age;  // replace me
 }
 
 
 // finds the sum of grades
 public int getSum()
 {
  // FINISH ME
  int sum = 0; 
  
  for (int i=0; i<grades.size(); i++)
  {
    sum = sum + grades.get(i);
  }

  return sum;  // replace me  
 }
 
 
 // finds the average of grades
 public double getAverage()
 {
  // FINISH ME
  // you may assume there is at least 1 grade
  int sum = 0; 
  
  for (int i=0; i<grades.size(); i++)
  {
    sum = sum + grades.get(i);
  }
 
  double average = (Double.valueOf(sum))/grades.size();
   
  return average;  // replace me  
 }
 

 // finds the highest grade of grades
 public int getHighestGrade()
 {
  // FINISH ME
  int highestGrade = grades.get(0);
   
  for (int i=1; i<grades.size(); i++)
  {
    if (highestGrade < grades.get(i))
      highestGrade = grades.get(i);
    else 
      highestGrade = highestGrade;
  }   
  
  return highestGrade;  // replace me  
 }
 
 
 // finds the lowest grade of grades
 public int getLowestGrade()
 {
  // FINISH ME
    int lowestGrade = grades.get(0);
   
  for (int i=1; i<grades.size(); i++)
  {
    if (lowestGrade > grades.get(i))
      lowestGrade = grades.get(i);
    else 
      lowestGrade = lowestGrade;
  }   
   
  return lowestGrade;  // replace me  
 }

 
 // finds the difference of the highest and lowest grade
 public int getRange()
 {
  // FINISH ME
  
  int highestGrade = grades.get(0);
   
  for (int i=1; i<grades.size(); i++)
  {
    if (highestGrade < grades.get(i))
      highestGrade = grades.get(i);
    else 
      highestGrade = highestGrade;
  }   
  
  int lowestGrade = grades.get(0);
   
  for (int i=1; i<grades.size(); i++)
  {
    if (lowestGrade > grades.get(i))
      lowestGrade = grades.get(i);
    else 
      lowestGrade = lowestGrade;
  }   
   
  int range = highestGrade-lowestGrade;
  
  return range;  // replace me  
 }

 
 // finds the number of val grades found in grades
 // for example if val is 100, it would count the
 //     number of times 100 appears in the list grades
 public int getCountOf(int val)
 {
  // FINISH ME
   int count = 0;
   
  for (int i=0; i<grades.size(); i++)
  {
    if (grades.get(i) == val)
      count++;
  }   
  
  return count;  // replace me  
 }


 // finds the number of grades greater than or equal to val
 public int getNumGTE(int val)
 {
  // FINISH ME
  
   int count = 0;
   
  for (int i=0; i<grades.size(); i++)
  {
    if (grades.get(i) >= val)
      count++;
  }   
  
  return count;  // replace me  
  
 }

 // finds the number of grades less than val
 public int getNumLT(int val)
 {
  // FINISH ME
  
   int count = 0;
   
  for (int i=0; i<grades.size(); i++)
  {
    if (grades.get(i) <= val)
      count++;
  }   
  
  return count;  
  
 }

 public String getGradeList()
 {
  String output = "";
  
  // FINISH ME
  // get a list of all of the grades separated with " "
  for (int i=0; i<grades.size(); i++)
  {
    output = output + grades.get(i) + " ";
  }   
   
  return output;
 }
 
  
 // a Priority Queue uses the compareTo method to get the order
 public int compareTo(Object other)
 {
  Student otherStudent = (Student) other;
  
  // FINISH ME
  // order by average of grades
  
  
  // get the average of this student
  double average = getAverage();
  
  // get the average of the other student
  double averageOther = otherStudent.getAverage();
  
  
  // now compare this student's average to the other student's average (<)
  // if less than, return -1
   if (average < averageOther)
     return -1;  
   
  // now compare this student's average to the other student's average (>)
  // if greater than, return 1
  
  if (average > averageOther)
    return 1;
  
  return 0;  
 }
 
}  // end of class Student



